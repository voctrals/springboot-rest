package cn.voctrals.boot.util.aliyun;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.aliyuncs.sms.model.v20160927.SingleSendSmsRequest;
import com.aliyuncs.sms.model.v20160927.SingleSendSmsResponse;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;

/**
 * 短信相关
 */
public class SMSUtil {

    /** 签名名称：阿里云平台必须为通过 */
    private static final String SING_NAME = "单刀职入";
    /** 验证码模板代码：阿里云平台必须为通过 */
    private static final String VERIFY_TEMPLATE_CODE = "SMS_31615049";

    /** 通过审核通知模板代码：阿里云平台必须为通过 */
    private static final String PASS_INFO_TEMPLATE_CODE = "SMS_33925124";
    /** 未通过审核通知模板代码：阿里云平台必须为通过 */
    private static final String DENY_INFO_TEMPLATE_CODE = "SMS_33875277";
    /** 反馈信息已处理模板，参数：name:用户名称 */
    public static final String FEEDBACK_PROCESSED_TEMPLATE_CODE = "SMS_34400180";

    /**
     * 发送验证码
     * @param phone 手机号码
     * @param code  验证码
     * @return boolean 是否发送成功
     */
    public static boolean sendVerify(String phone, String code) {
        return sendMsg(phone, VERIFY_TEMPLATE_CODE, "{\"code\":\"" + code + "\"}");
    }

    /**
     * 发送通过审核的通知消息
     * @param phone 手机号码
     * @return boolean 是否发送成功
     */
    public static boolean sendPassMsg(String phone) {
        return sendMsg(phone, PASS_INFO_TEMPLATE_CODE, "{}");
    }

    /**
     * 发送未通过审核的通知消息
     * @param phone 手机号码
     * @return boolean 是否发送成功
     */
    public static boolean sendDenyMsg(String phone) {
        return sendMsg(phone, DENY_INFO_TEMPLATE_CODE, "{}");
    }

    /**
     * 发送通知消息
     * @param phone 手机号码
     * @param template 模板
     * @param parameters 参数
     * @return boolean 是否发送成功
     */
    public static boolean sendInfoMsg(String phone, String template, Map<String, String> parameters) {
        Gson gson = new Gson();
        return sendMsg(phone, template, gson.toJson(parameters));
    }

    /**
     * 发送消息
     * @param phone 手机号码
     * @param templateCode  模板代码
     * @param parameters    替代参数
     * @return boolean 是否发送成功
     */
    private static boolean sendMsg(String phone, String templateCode, String parameters) {

        IClientProfile profile = DefaultProfile.getProfile(AliConst.REGION_ID, AliConst.ACCESS_KEY, AliConst.ACCESS_SECRET);

        try {
            DefaultProfile.addEndpoint(AliConst.REGION_ID, AliConst.REGION_ID, "Sms",  "sms.aliyuncs.com");
            IAcsClient client = new DefaultAcsClient(profile);
            SingleSendSmsRequest request = new SingleSendSmsRequest();

            request.setSignName(SING_NAME);
            request.setTemplateCode(templateCode);
            request.setParamString(parameters);
            request.setRecNum(phone);
            SingleSendSmsResponse httpResponse = client.getAcsResponse(request);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public static void main(String[] args) {
//        boolean result = sendVerify("13342284889", "555888");
//        System.out.println(result);

//        Map<String, String> testMap = new HashMap<String, String>();
//        testMap.put("name", "liulei");
//        testMap.put("age", "12");
//        testMap.put("gender", "male");
//
//        JSONObject a = JSONObject.fromObject(testMap);

//        boolean denyMsg = sendDenyMsg("13342284889");
//        System.out.print("Deny : " + denyMsg);
//        boolean passMsg = sendPassMsg("13342284889");
//        System.out.print("Pass : " + passMsg);
    }

}
