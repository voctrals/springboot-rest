package cn.voctrals.boot.util.aliyun;

/**
 * 阿里云常量
 */
public class AliConst {

    /** 服务器的节点ID */
    public static final String REGION_ID = "cn-beijing";

    /** 服务器的ACCESS_KEY */
    public static final String ACCESS_KEY = "LTAIsVCeR22QVAoa";

    /** 服务器的ACCESS_SECRET */
    public static final String ACCESS_SECRET = "y5wzmR94Ss0rVCh0vbvxoS1EzWUxD9";

    /** 签名名称：阿里云平台必须为通过 */
    private static final String SING_NAME = "单刀职入";

}
