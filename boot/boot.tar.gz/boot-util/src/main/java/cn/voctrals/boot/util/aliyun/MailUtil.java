package cn.voctrals.boot.util.aliyun;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dm.model.v20151123.SingleSendMailRequest;
import com.aliyuncs.dm.model.v20151123.SingleSendMailResponse;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.exceptions.ServerException;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * 邮件相关
 */
public class MailUtil {

//    /**
//     * 通知通过审核
//     *
//     * @param mailTo
//     * @return
//     */
//    public static boolean passMail(String mailTo) {
//
//        StringBuilder sb = new StringBuilder();
//
//        sb.append("<p>用户你好！</p>");
//        sb.append("<p>恭喜您，您的申请已经通过。尽快体验吧！</p>");
//        sb.append("<p><a href=\"www.boot.com\">www.boot.com</a></p>");
//        sb.append("<p>来自单刀职入系统管理员</p>");
//        sb.append("<p style=\"color:red; font:8px;\">系统邮件，请勿回复</p>");
//
//        return sendMail(mailTo, sb.toString());
//    }

//    /**
//     * 通知未通过审核
//     *
//     * @param mailTo
//     * @return
//     */
//    public static boolean denyMail(String mailTo) {
//
//        StringBuilder sb = new StringBuilder();
//
//        sb.append("<p>用户你好！</p>");
//        sb.append("<p>您的申请被拒绝，请重新提交贵公司的资料！</p>");
//        sb.append("<p><a href=\"www.boot.com\">www.boot.com</a></p>");
//        sb.append("<p>来自单刀职入系统管理员</p>");
//        sb.append("<p style=\"color:red; font:8px;\">系统邮件，请勿回复</p>");
//
//        return sendMail(mailTo, sb.toString());
//    }

//    /**
//     * 通知未通过审核
//     *
//     * @param mailTo
//     * @param url
//     * @return
//     */
//    public static boolean resetPass(String mailTo, String url) {
//        StringBuilder sb = new StringBuilder();
//
//        sb.append("<p>用户你好！</p>");
//        sb.append("<p>您正在重置您的密码，如不是本人操作，请重置您的登录信息！</p>");
//        sb.append("<p>如是本人操作，点击下面的链接，即可重置密码。</p>");
//        sb.append("<p><a href=\"" + url + "\">" + url + "</a></p>");
//        sb.append("<p>此链接有效时间为30分钟。</p>");
//        sb.append("<p>来自单刀职入系统管理员</p>");
//        sb.append("<p style=\"color:red; font:8px;\">系统邮件，请勿回复</p>");
//
//        return sendMail(mailTo, sb.toString());
//    }

//    /**
//     * 通知添加新用户
//     */
//    public static boolean notifyNewUser(String mailTo, String url) {
//        StringBuffer sb = new StringBuffer();
//        sb.append("<p>用户你好！</p>");
//        sb.append("<p>您正在创建您的账号！</p>");
//        sb.append("<p>点击下面的链接，即可登陆创建页面</p>");
//        sb.append("<p><a href=\"" + url + "\">" + url + "</a></p>");
//        sb.append("<p>此链接有效时间为30分钟。</p>");
//        sb.append("<p>来自单刀职入系统管理员</p>");
//        sb.append("<p style=\"color:red; font:8px;\">系统邮件，请勿回复</p>");
//
//        return sendMail(mailTo,sb.toString());
//    }

//    /**
//     * 通知通过邮箱修改密码
//     */
//    public static boolean notifyPwdByEmail(String mailTo, String url) {
//        StringBuffer sb = new StringBuffer();
//        sb.append("<p>用户你好！</p>");
//        sb.append("<p>您正在通过邮箱修改密码</p>");
//        sb.append("<p>点击下面的链接，即可登修改密码页面</p>");
//        sb.append("<p><a href=\"" + url + "\">" + url + "</a></p>");
//        sb.append("<p>此链接有效时间为24小时</p>");
//        sb.append("<p>来自单刀职入系统管理员</p>");
//        sb.append("<p style=\"color:red; font:8px;\">系统邮件，请勿回复</p>");
//
//        return sendMail(mailTo,sb.toString());
//    }
//
//    /**
//     * 人才转发发送邮件
//     */
//    public static boolean forwardApplicant(String mailTo, String url) {
//        StringBuffer sb = new StringBuffer();
//        sb.append("<p>你好！</p>");
//        sb.append("<p>xxx给您发送了人才信息</p>");
//        sb.append("<p>点击下面的链接，查看信息</p>");
//        sb.append("<p><a href=\"" + url + "\">" + url + "</a></p>");
//        sb.append("<p>此链接有效时间为24小时</p>");
//        sb.append("<p>来自单刀职入系统管理员</p>");
//        sb.append("<p style=\"color:red; font:8px;\">系统邮件，请勿回复</p>");
//
//        return sendMail(mailTo,sb.toString());
//    }

//    private static boolean sendMailByTemplate(String mailTo, String templateName) {
//        String content =
//    }
    /**
     * 发送邮件
     *
     * @param mailTo     收件人
     * @param content    邮件内容
     * @return
     */
    public static boolean sendMail(String mailTo, String content) {
        boolean result = true;
        IClientProfile profile = DefaultProfile.getProfile(AliConst.REGION_ID, AliConst.ACCESS_KEY, AliConst.ACCESS_SECRET);
        IAcsClient client = new DefaultAcsClient(profile);
        SingleSendMailRequest request = new SingleSendMailRequest();
        try {
            request.setAccountName("service@notice.voctrals.cn");
            request.setFromAlias("单刀职入管理员");
            request.setAddressType(1);
            request.setTagName("boot");
            request.setReplyToAddress(false);
            request.setToAddress(mailTo);
            request.setSubject("单刀职入消息通知");
            request.setHtmlBody(content);
            SingleSendMailResponse httpResponse = client.getAcsResponse(request);
            System.out.print(httpResponse);
        } catch (ServerException e) {
            e.printStackTrace();
            result = false;
        } catch (ClientException e) {
            e.printStackTrace();
            result = false;
        }

        return result;
    }

    public static void main(String[] args) {
//        System.out.println(passMail("liulei@atm-dl.com"));
//        System.out.println(denyMail("liulei@atm-dl.com"));
    }

}
