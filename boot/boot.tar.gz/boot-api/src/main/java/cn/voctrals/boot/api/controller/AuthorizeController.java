package cn.voctrals.boot.api.controller;

import cn.voctrals.boot.api.model.OAuthModel;
import cn.voctrals.boot.core.exception.AppException;
import cn.voctrals.boot.core.util.CacheUtils;
import cn.voctrals.boot.core.util.ErrorCode;
import cn.voctrals.boot.service.AccountService;
import cn.voctrals.boot.service.dto.AccountDto;
import cn.voctrals.boot.util.Constants;
import org.apache.oltu.oauth2.as.issuer.MD5Generator;
import org.apache.oltu.oauth2.as.issuer.OAuthIssuerImpl;
import org.apache.oltu.oauth2.as.request.OAuthAuthzRequest;
import org.apache.oltu.oauth2.common.OAuth;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.oltu.oauth2.common.message.types.ResponseType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.net.URISyntaxException;

/**
 * Created by hudingchen on 08/11/2016.
 */
@RestController
public class AuthorizeController extends RestBaseController {

    @Autowired
    private AccountService accountService;

    private Cache oauthTokenCache;

    @Autowired
    public AuthorizeController(CacheManager cacheManager) {
        this.oauthTokenCache = cacheManager.getCache(Constants.ApiCacheName.OAUTH_TOKEN);
    }

    /**
     * @param request
     *          client_id 必须
     *          response_type 必须
     * @return
     * @throws URISyntaxException
     * @throws OAuthSystemException
     */
    @RequestMapping(value = "/authorize", method = RequestMethod.GET)
    public Object authorize(HttpServletRequest request) throws Exception {
        OAuthAuthzRequest oauthRequest = new OAuthAuthzRequest(request);

        String clientId = oauthRequest.getClientId();

        AccountDto accountDto = accountService.selectAccountByPhone(clientId, Constants.AccountType.APPLICANT);
        if (accountDto == null) {
            throw new AppException(ErrorCode.INVALID_ACCOUNT);
        }

        //生成授权码
        String authorizationCode = null;
        //responseType目前仅支持CODE，另外还有TOKEN
        String responseType = oauthRequest.getParam(OAuth.OAUTH_RESPONSE_TYPE);
        if (responseType.equals(ResponseType.CODE.toString())) {
            OAuthIssuerImpl oauthIssuerImpl = new OAuthIssuerImpl(new MD5Generator());
            authorizationCode = oauthIssuerImpl.authorizationCode();
            CacheUtils.put(oauthTokenCache, authorizationCode, clientId);
        }
        OAuthModel oAuthModel = new OAuthModel();
        oAuthModel.setCode(authorizationCode);
        return super.makeOneResult(oAuthModel);
    }

}
