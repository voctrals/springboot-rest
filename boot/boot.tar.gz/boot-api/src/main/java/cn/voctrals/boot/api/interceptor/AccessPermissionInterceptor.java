package cn.voctrals.boot.api.interceptor;

import cn.voctrals.boot.api.controller.*;
import cn.voctrals.boot.core.util.CacheUtils;
import cn.voctrals.boot.util.Constants;
import org.apache.oltu.oauth2.common.message.types.ParameterStyle;
import org.apache.oltu.oauth2.rs.request.OAuthAccessResourceRequest;
import org.apache.shiro.authz.UnauthorizedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.BasicErrorController;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by hudingchen on 13/11/2016.
 */
public class AccessPermissionInterceptor extends HandlerInterceptorAdapter {

    @Autowired
    private CacheManager cacheManager;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HandlerMethod handlerMethod = (HandlerMethod)handler;
        Class beanType = handlerMethod.getBeanType();
        for (ControllerModel controller : anonControllers()) {
            if (beanType == controller.clazz) {
                if (controller.exceptMethods != null) {
                    boolean isExcept = false;
                    for (String method : controller.exceptMethods) {
                        if (handlerMethod.getMethod().getName().equals(method)) {
                            isExcept = true;
                            break;
                        }
                    }
                    if (isExcept) {
                        return true;
                    }
                }
                return true;
            }
        }
        //构建OAuth资源请求
        OAuthAccessResourceRequest oauthRequest = new OAuthAccessResourceRequest(request, ParameterStyle.HEADER);
        //获取Access Token
        String accessToken = oauthRequest.getAccessToken();

        Cache cache = cacheManager.getCache(Constants.ApiCacheName.OAUTH_TOKEN);

        //验证Access Token
        if (!CacheUtils.containsKey(cache, accessToken)) {
            throw new UnauthorizedException();
        }

        return true;
    }

    @Bean
    private List<ControllerModel> anonControllers() {
        List<ControllerModel> controllers = new ArrayList<>();
        controllers.add(new ControllerModel(BasicErrorController.class));
        controllers.add(new ControllerModel(AuthorizeController.class));
        controllers.add(new ControllerModel(AccessTokenController.class));

        return controllers;
    }

    class ControllerModel {
        private Class clazz;
        private String[] exceptMethods;
        public ControllerModel(Class clazz) {
            this(clazz, null);
        }
        public ControllerModel(Class clazz, String[] exceptMethods) {
            this.clazz = clazz;
            this.exceptMethods = exceptMethods;
        }
    }
}
