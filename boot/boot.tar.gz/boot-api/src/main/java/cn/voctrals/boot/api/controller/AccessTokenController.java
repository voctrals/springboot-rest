package cn.voctrals.boot.api.controller;

import cn.voctrals.boot.api.model.OAuthModel;
import cn.voctrals.boot.core.exception.AppException;
import cn.voctrals.boot.core.util.CacheUtils;
import cn.voctrals.boot.core.util.ErrorCode;
import cn.voctrals.boot.service.AccountService;
import cn.voctrals.boot.service.dto.AccountDto;
import cn.voctrals.boot.util.Constants;
import org.apache.oltu.oauth2.as.issuer.MD5Generator;
import org.apache.oltu.oauth2.as.issuer.OAuthIssuer;
import org.apache.oltu.oauth2.as.issuer.OAuthIssuerImpl;
import org.apache.oltu.oauth2.as.request.OAuthTokenRequest;
import org.apache.oltu.oauth2.common.OAuth;
import org.apache.oltu.oauth2.common.message.types.GrantType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by hudingchen on 09/11/2016.
 */
@RestController
public class AccessTokenController extends RestBaseController {

    @Autowired
    private AccountService accountService;

    private Cache oauthTokenCache;

    @Autowired
    public AccessTokenController(CacheManager cacheManager) {
        this.oauthTokenCache = cacheManager.getCache(Constants.ApiCacheName.OAUTH_TOKEN);
    }

    @RequestMapping(value = "/accessToken", method = RequestMethod.POST)
    public Object token(HttpServletRequest request) throws Exception {
        OAuthTokenRequest oauthRequest = new OAuthTokenRequest(request);
        String authCode = oauthRequest.getParam(OAuth.OAUTH_CODE);
        if (oauthRequest.getParam(OAuth.OAUTH_GRANT_TYPE).equals(GrantType.AUTHORIZATION_CODE.toString())) {
            if (!CacheUtils.containsKey(oauthTokenCache, authCode)) {
                throw new AppException(ErrorCode.INVALID_AUTHORIZATION_CODE);
            }
        }

        // check phone and password
        String phone = oauthRequest.getClientId();
        String password = oauthRequest.getClientSecret();

        AccountDto result = accountService.selectAccountByPhone(phone, Constants.AccountType.APPLICANT);
        if (result == null || !result.getPassword().equals(password)) {
            throw new AppException(ErrorCode.INVALID_ACCOUNT);
        }

        OAuthIssuer oauthIssuerImpl = new OAuthIssuerImpl(new MD5Generator());
        final String accessToken = oauthIssuerImpl.accessToken();
        CacheUtils.put(oauthTokenCache, accessToken, "access_token_name");

        OAuthModel oAuthModel = new OAuthModel();
        oAuthModel.setAccessToken(accessToken);
        return super.makeOneResult(oAuthModel);
    }

}
