package cn.voctrals.boot.service;

import cn.voctrals.boot.core.exception.AppException;
import cn.voctrals.boot.core.util.BeanMapper;
import cn.voctrals.boot.core.util.ErrorCode;
import cn.voctrals.boot.core.util.GenUtils;
import cn.voctrals.boot.dao.AccountDao;
import cn.voctrals.boot.dao.entity.Account;
import cn.voctrals.boot.service.dto.AccountDto;
import cn.voctrals.boot.util.Constants;
import cn.voctrals.boot.util.rongcloud.RongCloudUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AccountService {

    @Autowired
    private AccountDao accountDao;

    /**
     * 账户注册
     * @param accountDto 账户信息
     * @return 账户信息
     */
    @Transactional
    public AccountDto insert(AccountDto accountDto) {
        Account account = BeanMapper.map(accountDto, Account.class);
        Account checkAccount = accountDao.selectByPhone(account);
        if (checkAccount != null) {
            throw new AppException(ErrorCode.DATA_EXIST);
        }

        account.setId(GenUtils.uuid());
        account.setPassword(GenUtils.encrypt(account.getPassword()));
        account.setRongToken(RongCloudUtil.getToken(account.getId(), account.getPhone()).getToken());

        accountDao.insert(account);

        return BeanMapper.map(account, AccountDto.class);
    }


    /**
     * 根据手机号获取账户信息
     * @param phone 手机号
     * @param accountType 用户类型
     * @return 账户信息
     */
    public AccountDto selectAccountByPhone(String phone, String accountType) {
        Account account = new Account();
        account.setPhone(phone);
        account.setAccountType(accountType);
        Account result = accountDao.selectByPhone(account);
        return BeanMapper.map(result, AccountDto.class);
    }


    /**
     * 修改密码
     * @param accountDto 账户信息
     * @return 账户信息
     */
    public AccountDto modifyPassword(AccountDto accountDto) {
        Account checker = new Account();
        checker.setPhone(accountDto.getPhone());
        checker.setAccountType(Constants.AccountType.APPLICANT);
        Account result = accountDao.selectByPhone(checker);
        if (result == null) {
            throw new AppException(ErrorCode.ITEM_NOT_EXIST, new String[]{"phone"});
        }

        Account account = BeanMapper.map(accountDto, Account.class);
        account.setId(result.getId());
        account.setPassword(GenUtils.encrypt(account.getPassword()));
        accountDao.updateByPrimaryKeySelective(account);
        return BeanMapper.map(account, AccountDto.class);
    }

    /**
     * 修改密码
     * @param accountDto 账户信息
     * @param oldPassword 账户原密码
     * @return 账户信息
     */
    public AccountDto modifyPassword(AccountDto accountDto, String oldPassword) {
        Account account = BeanMapper.map(accountDto, Account.class);
        account = accountDao.selectByPrimaryKey(account);
        if (StringUtils.equals(GenUtils.encrypt(oldPassword), account.getPassword())) {
            accountDto.setPhone(account.getPhone());
            return modifyPassword(accountDto);
        } else {
            throw new AppException(ErrorCode.INVALID_VALUE, new String[]{"password"});
        }
    }


    /**
     * 修改手机号码
     * @param accountDto 账户信息
     * @return 账户信息
     */
    public AccountDto modifyPhone(AccountDto accountDto) {
        Account account = BeanMapper.map(accountDto, Account.class);

        // 判断用户是否已经存在
        account.setAccountType(Constants.AccountType.APPLICANT);
        Account alreadyAccount = accountDao.selectByPhone(account);
        if (alreadyAccount != null) {
            throw new AppException(ErrorCode.DATA_EXIST);
        }

        accountDao.updateByPrimaryKeySelective(account);
        return BeanMapper.map(account, AccountDto.class);
    }
}
