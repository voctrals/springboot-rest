package cn.voctrals.boot.service.dto;

import cn.voctrals.boot.core.util.ValidateUtils;
import cn.voctrals.boot.core.validator.constraints.MaxByteLength;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Pattern;
import java.io.Serializable;

public class AccountDto extends BaseDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 手机号
     */
    @NotEmpty
    @MaxByteLength(value = 11)
    private String phone;

    /**
     * 邮箱
     */
    @MaxByteLength(value = 100)
    private String email;

    /**
     * 密码
     */
    @NotEmpty
    @Pattern(regexp = ValidateUtils.ALPHANUMERIC)
    @MaxByteLength(value = 100)
    @Length(min = 6, max = 16)
    private String password;

    /**
     * 账户类型
     */
    @NotEmpty
    private String accountType;

    /**
     * 验证码
     */
    private String vcode;

    private String applicantId;

    /**
     * 融云TOKEN
     */
    private String rongToken;

    /**
     * 融云名字
     */
    private String rongName;

    /**
     * 融云头像
     */
    private String rongHead;

    /**
     * 用户描述
     */
    private String accountDesc;

    /**
     * 用户名称
     */
    private String username;

    /**
     * 公司id
     */
    private String companyId;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getVcode() {
        return vcode;
    }

    public void setVcode(String vcode) {
        this.vcode = vcode;
    }

    public String getApplicantId() {
        return applicantId;
    }

    public void setApplicantId(String applicantId) {
        this.applicantId = applicantId;
    }

    public String getRongToken() {
        return rongToken;
    }

    public void setRongToken(String rongToken) {
        this.rongToken = rongToken;
    }

    public String getRongName() {
        return rongName;
    }

    public void setRongName(String rongName) {
        this.rongName = rongName;
    }

    public String getRongHead() {
        return rongHead;
    }

    public void setRongHead(String rongHead) {
        this.rongHead = rongHead;
    }

    public String getAccountDesc() {
        return accountDesc;
    }

    public void setAccountDesc(String accountDesc) {
        this.accountDesc = accountDesc;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }
}