package cn.voctrals.boot.dao.entity;

import java.io.Serializable;

public class Account extends BaseModel implements Serializable {

    private static final long serialVersionUID = 1L;
    
    /** 账户ID */
    private String id;

    /** 手机号 */
    private String phone;

    /** 邮箱 */
    private String email;

    /** 密码 */
    private String password;

    /** 账户类型 */
    private String accountType;

    /** 融云TOKEN */
    private String rongToken;

    /** 融云名字 */
    private String rongName;

    /** 融云头像 */
    private String rongHead;

    /** 用户描述 */
    private String accountDesc;

    /** 用户姓名 */
    private String username;

    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    public String getAccountType() {
        return accountType;
    }
    
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getRongToken() {
        return rongToken;
    }

    public void setRongToken(String rongToken) {
        this.rongToken = rongToken;
    }

    public String getRongName() {
        return rongName;
    }

    public void setRongName(String rongName) {
        this.rongName = rongName;
    }

    public String getRongHead() {
        return rongHead;
    }

    public void setRongHead(String rongHead) {
        this.rongHead = rongHead;
    }

    public String getAccountDesc() {
        return accountDesc;
    }

    public void setAccountDesc(String accountDesc) {
        this.accountDesc = accountDesc;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}