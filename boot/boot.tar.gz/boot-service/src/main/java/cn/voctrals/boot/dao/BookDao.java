package cn.voctrals.boot.dao;


import cn.voctrals.boot.dao.entity.Book;

    public interface BookDao extends BaseMasterDao<Book, Book> {
	
}
