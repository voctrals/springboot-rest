package cn.voctrals.boot.dao;

import cn.voctrals.boot.dao.entity.Account;

public interface AccountDao extends BaseMasterDao<Account, Account> {

    Account selectByPhone(Account account);

    void updatePasswordByPhone(Account account);

    Account selectByPhoneNum(Account account);

    Account getRongCloudInfo(Account account);

    int updateAccountInfo(Account account);

    Account selectUserInfoByAccountId(Account account);

    void deleteUserByAccountId(Account account);

    void updateUserInfoByAccountId(Account account);

    Account selectInfoByEmail(Account account);

    void updatePasswordById(Account account);

    Account selectInfoById(Account account);

    Account selectAccountInfo(Account account);

}
